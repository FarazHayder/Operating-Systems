#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#define CUSTOM_STACK_SIZE (1024 * 1024)  // 1MB stack size

// Structure to store thread information
struct ThreadInfo {
    pthread_t thread_id;
    size_t stack_size;
    int policy;
    int priority;
};

// Function to print thread attributes
void print_thread_attributes(pthread_attr_t *attr) {
    size_t stack_size;
    int policy;
    struct sched_param param;
    
    // Get stack size
    pthread_attr_getstacksize(attr, &stack_size);
    
    // Get scheduling policy
    pthread_attr_getschedpolicy(attr, &policy);
    
    // Get scheduling priority
    pthread_attr_getschedparam(attr, &param);
    
    printf("\nThread Attributes:\n");
    printf("Stack Size: %zu bytes\n", stack_size);
    printf("Scheduling Policy: %s\n", 
           (policy == SCHED_FIFO) ? "SCHED_FIFO" :
           (policy == SCHED_RR) ? "SCHED_RR" : "SCHED_OTHER");
    printf("Priority: %d\n", param.sched_priority);
}

// Thread function
void* thread_function(void* arg) {
    struct ThreadInfo *info = (struct ThreadInfo*)arg;
    
    printf("\nThread executing with ID: %lu\n", (unsigned long)pthread_self());
    
    // Simulate some work
    printf("Thread performing work...\n");
    sleep(2);
    
    printf("Thread work completed\n");
    return NULL;
}

int main() {
    pthread_attr_t attr;
    pthread_t thread;
    struct ThreadInfo thread_info;
    int result;
    
    // Initialize thread attributes
    result = pthread_attr_init(&attr);
    if (result != 0) {
        printf("Error initializing attributes: %s\n", strerror(result));
        return 1;
    }
    
    // Set stack size
    result = pthread_attr_setstacksize(&attr, CUSTOM_STACK_SIZE);
    if (result != 0) {
        printf("Error setting stack size: %s\n", strerror(result));
        pthread_attr_destroy(&attr);
        return 1;
    }
    
    // Set scheduling policy to SCHED_FIFO
    result = pthread_attr_setschedpolicy(&attr, SCHED_FIFO);
    if (result != 0) {
        printf("Error setting scheduling policy: %s\n", strerror(result));
        printf("Note: SCHED_FIFO requires root privileges\n");
        // Fallback to default scheduling policy
        pthread_attr_setschedpolicy(&attr, SCHED_OTHER);
    }
    
    // Set scheduling priority
    struct sched_param param;
    param.sched_priority = 1;  // Minimum priority for SCHED_OTHER
    result = pthread_attr_setschedparam(&attr, &param);
    if (result != 0) {
        printf("Error setting scheduling parameters: %s\n", strerror(result));
        pthread_attr_destroy(&attr);
        return 1;
    }
    
    // Print the configured attributes
    printf("Configured Thread Attributes:\n");
    print_thread_attributes(&attr);
    
    // Create thread with attributes
    result = pthread_create(&thread, &attr, thread_function, &thread_info);
    if (result != 0) {
        printf("Error creating thread: %s\n", strerror(result));
        pthread_attr_destroy(&attr);
        return 1;
    }
    
    // Store thread information
    thread_info.thread_id = thread;
    pthread_attr_getstacksize(&attr, &thread_info.stack_size);
    pthread_attr_getschedpolicy(&attr, &thread_info.policy);
    
    // Wait for thread to complete
    printf("\nMain thread waiting for worker thread to complete...\n");
    result = pthread_join(thread, NULL);
    if (result != 0) {
        printf("Error joining thread: %s\n", strerror(result));
        pthread_attr_destroy(&attr);
        return 1;
    }
    
    printf("\nThread completed successfully!\n");
    
    // Clean up
    pthread_attr_destroy(&attr);
    
    return 0;
}
