gcc -o t2 q2.c -pthread -lm
