#include <stdio.h>
#include <pthread.h>
#include <math.h>
#include <stdlib.h>

// Structure to hold input and output parameters for threads
struct ThreadData {
    double input;
    double* result;
    pthread_mutex_t* mutex;
};

// Function to calculate square
void* calculate_square(void* arg) {
    struct ThreadData* data = (struct ThreadData*)arg;
    
    pthread_mutex_lock(data->mutex);
    *(data->result) = data->input * data->input;
    printf("Square calculation completed: %.2f² = %.2f\n", 
           data->input, *(data->result));
    pthread_mutex_unlock(data->mutex);
    
    return NULL;
}

// Function to calculate square root
void* calculate_sqrt(void* arg) {
    struct ThreadData* data = (struct ThreadData*)arg;
    
    pthread_mutex_lock(data->mutex);
    if (data->input >= 0) {
        *(data->result) = sqrt(data->input);
        printf("Square root calculation completed: √%.2f = %.2f\n", 
               data->input, *(data->result));
    } else {
        printf("Error: Cannot calculate square root of a negative number!\n");
        *(data->result) = -1;
    }
    pthread_mutex_unlock(data->mutex);
    
    return NULL;
}

int main() {
    // Local variables
    double input_number;
    double square_result = 0;
    double sqrt_result = 0;
    pthread_t thread_square, thread_sqrt;
    pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

    // Create thread data structures
    struct ThreadData square_data;
    struct ThreadData sqrt_data;

    // Get input from user
    printf("Enter a number: ");
    if (scanf("%lf", &input_number) != 1) {
        printf("Error: Invalid input\n");
        return 1;
    }

    // Initialize thread data structures
    square_data.input = input_number;
    square_data.result = &square_result;
    square_data.mutex = &mutex;

    sqrt_data.input = input_number;
    sqrt_data.result = &sqrt_result;
    sqrt_data.mutex = &mutex;

    // Create threads
    if (pthread_create(&thread_square, NULL, calculate_square, &square_data) != 0) {
        printf("Error creating square calculation thread\n");
        return 1;
    }

    if (pthread_create(&thread_sqrt, NULL, calculate_sqrt, &sqrt_data) != 0) {
        printf("Error creating square root calculation thread\n");
        return 1;
    }

    // Wait for threads to complete
    pthread_join(thread_square, NULL);
    pthread_join(thread_sqrt, NULL);

    // Print final results
    printf("\nFinal Results:\n");
    printf("Input number: %.2f\n", input_number);
    printf("Square: %.2f\n", square_result);
    if (input_number >= 0) {
        printf("Square root: %.2f\n", sqrt_result);
    }

    // Cleanup
    pthread_mutex_destroy(&mutex);

    return 0;
}
