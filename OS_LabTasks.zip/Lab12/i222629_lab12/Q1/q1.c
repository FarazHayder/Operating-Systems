#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

// Global variables for input numbers and results
double num1, num2;
double add_result, sub_result, mul_result, div_result;

// Mutex for thread synchronization
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

// Function to perform addition
void* addition(void* arg) {
    pthread_mutex_lock(&mutex);
    add_result = num1 + num2;
    printf("Addition completed: %.2f + %.2f = %.2f\n", num1, num2, add_result);
    pthread_mutex_unlock(&mutex);
    return NULL;
}

// Function to perform subtraction
void* subtraction(void* arg) {
    pthread_mutex_lock(&mutex);
    sub_result = num1 - num2;
    printf("Subtraction completed: %.2f - %.2f = %.2f\n", num1, num2, sub_result);
    pthread_mutex_unlock(&mutex);
    return NULL;
}

// Function to perform multiplication
void* multiplication(void* arg) {
    pthread_mutex_lock(&mutex);
    mul_result = num1 * num2;
    printf("Multiplication completed: %.2f * %.2f = %.2f\n", num1, num2, mul_result);
    pthread_mutex_unlock(&mutex);
    return NULL;
}

// Function to perform division
void* division(void* arg) {
    pthread_mutex_lock(&mutex);
    if (num2 != 0) {
        div_result = num1 / num2;
        printf("Division completed: %.2f / %.2f = %.2f\n", num1, num2, div_result);
    } else {
        printf("Error: Division by zero!\n");
        div_result = 0;
    }
    pthread_mutex_unlock(&mutex);
    return NULL;
}

int main() {
    // Thread declarations
    pthread_t thread_add, thread_sub, thread_mul, thread_div;

    // Get input from user
    printf("Enter first number: ");
    scanf("%lf", &num1);
    printf("Enter second number: ");
    scanf("%lf", &num2);

    // Create threads for each operation
    if (pthread_create(&thread_add, NULL, addition, NULL) != 0) {
        printf("Error creating addition thread\n");
        return 1;
    }
    if (pthread_create(&thread_sub, NULL, subtraction, NULL) != 0) {
        printf("Error creating subtraction thread\n");
        return 1;
    }
    if (pthread_create(&thread_mul, NULL, multiplication, NULL) != 0) {
        printf("Error creating multiplication thread\n");
        return 1;
    }
    if (pthread_create(&thread_div, NULL, division, NULL) != 0) {
        printf("Error creating division thread\n");
        return 1;
    }

    // Wait for all threads to complete
    pthread_join(thread_add, NULL);
    pthread_join(thread_sub, NULL);
    pthread_join(thread_mul, NULL);
    pthread_join(thread_div, NULL);

    // Print final results
    printf("\nFinal Results:\n");
    printf("Addition: %.2f\n", add_result);
    printf("Subtraction: %.2f\n", sub_result);
    printf("Multiplication: %.2f\n", mul_result);
    if (num2 != 0) {
        printf("Division: %.2f\n", div_result);
    }

    // Destroy mutex
    pthread_mutex_destroy(&mutex);

    return 0;
}
