#!/bin/bash
dir="/dir1"
if [ ! -d "$dir" ]; then
    echo "Directory not found!"
else
    echo "Directory found."
fi