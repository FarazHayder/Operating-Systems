#!/bin/bash
count=1
while [ $count -le 10 ]
do
    if [ $count -eq 7 ]; then
        count=$((count+1))
        continue
    else
        echo "Count: $count"
    fi
        count=$((count+1))
done
