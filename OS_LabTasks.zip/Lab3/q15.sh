#!/bin/bash
count=1
while [ $count -le 10 ]
do
    if [ $count -eq 5 ]; then
        break
    else
        echo "Count: $count"
    fi
        count=$((count+1))
done
