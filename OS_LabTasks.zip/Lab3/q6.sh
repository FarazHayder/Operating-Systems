#!/bin/bash
echo "Enter 1st Number: "
read num1
echo "Enter 2nd Number: "
read num2
echo $((num1+num2))