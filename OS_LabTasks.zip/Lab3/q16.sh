#!/bin/bash
file="file1.txt"
dir="/dir1"
if [ -d "$dir" -a -w "$dir" -o -f "$file" -a -r "$file" ]; then
    echo "Conditions met successfully!"
else
    echo "Permission Denied!"
fi