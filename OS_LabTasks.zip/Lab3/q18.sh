#!/bin/bash

# Disable echoing of typed characters and enable reading without waiting for Enter
stty -echo -icanon

while [ true ]
do
    key=$(dd bs=1 count=1 2>/dev/null)
    if [ "$key" == "c" ]; then
        break
    else
        echo "running.."
    fi
done

# Reset terminal settings
stty echo icanon