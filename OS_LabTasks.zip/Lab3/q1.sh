#!/bin/bash
echo "Faraz Hayder"
echo 20
echo red
