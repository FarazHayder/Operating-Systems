#!/bin/bash
file="file1.txt"
if [ -f "$file" -a -r "$file" ]; then
    echo "The file is readable!"
elif [ ! -f "$file" ]; then
    echo "File not found!"
else
    echo "Permission Denied!"
fi