#!/bin/bash
file="file1.txt"
if [ -f "$file" -a -w "$file" ]; then
    echo "The file is writeable!"
elif [ ! -f "$file" ]; then
    echo "File not found!"
else
    echo "Permission Denied!"
fi