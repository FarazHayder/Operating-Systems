#!/bin/bash
echo "Enter a number: "
read number
if [ $number -lt 10 ]; then
        echo "It's a small number."
elif [ $number -gt 20 ]; then
        echo "It's a large number."
else
        echo "It's a medium number."
fi
