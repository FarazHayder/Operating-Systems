#!/bin/bash
echo "Enter a number: "
read number
if [ $number -gt 0 -a $number -lt 11 ]; then
        echo "small positive"
elif [ $number -gt 10 ]; then
        echo "large positive"
elif [ $number -lt 0 ]; then
        echo "negative"
elif [ $number -eq 0 ]; then
        echo "zero"
fi
