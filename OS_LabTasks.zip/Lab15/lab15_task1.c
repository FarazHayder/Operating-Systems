#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdlib.h>
#define BUFFER_SIZE 5
#define MAX_ITEMS 5

int buffer[BUFFER_SIZE];
int in = 0, out = 0;
int items_produced = 0;
int items_consumed = 0;

sem_t empty, full, mutex;

void *producer(void *arg)
{
	int item = 0;
	while (items_produced < MAX_ITEMS)
	{
		item++;
		sleep(1);

		sem_wait(&empty);
		sem_wait(&mutex);

		buffer[in] = item;
		printf("Producer produced: %d at position: %d\n", item, in);
		in = (in + 1) % BUFFER_SIZE;
		items_produced++;

		sem_post(&mutex);
		sem_post(&full);
	}
	return NULL;
}

void *consumer(void *arg)
{
	while (items_consumed < MAX_ITEMS)
	{
		sem_wait(&full);
		sem_wait(&mutex);

		int item = buffer[out];
		printf("Consumer consumed: %d from position: %d\n", item, out);
		out = (out + 1) % BUFFER_SIZE;
		items_consumed++;

		sem_post(&mutex);
		sem_post(&empty);

		sleep(2);
	}
	printf("All items consumed. Exiting...\n");
	exit(0);
	return NULL;
}

int main()
{
	pthread_t prod_thread, cons_thread;

	sem_init(&empty, 0, BUFFER_SIZE);
	sem_init(&full, 0, 0);
	sem_init(&mutex, 0, 1);

	pthread_create(&prod_thread, NULL, producer, NULL);
	pthread_create(&cons_thread, NULL, consumer, NULL);

	pthread_join(prod_thread, NULL);
	pthread_join(cons_thread, NULL);

	sem_destroy(&empty);
	sem_destroy(&full);
	sem_destroy(&mutex);

	return 0;
}
