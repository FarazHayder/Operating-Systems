#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

void *calcSum(void *arr)
{
    long *numbers = arr;
    long *result = malloc(sizeof(long));
    *result = numbers[0] + numbers[1];
    pthread_exit(result);
}

int main()
{
    long arr[2] = {1, 2};
    pthread_t thread;
    pthread_create(&thread, NULL, calcSum, (void *)arr);
    void *result;
    pthread_join(thread, &result);
    printf("Sum of %ld and %ld is %ld\n", arr[0], arr[1], *(long *)result);
}