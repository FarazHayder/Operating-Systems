#include <stdio.h>
#include <pthread.h>

void *calcSum(void *arr)
{
    long *numbers = arr;
    long result = numbers[0] + numbers[1];
    printf("Sum of %ld and %ld is %ld\n", numbers[0], numbers[1], result);
    pthread_exit(NULL);
}

int main()
{
    long arr[2] = {1, 2};
    pthread_t thread;
    pthread_create(&thread, NULL, calcSum, (void *)arr);
    pthread_join(thread, NULL);
}