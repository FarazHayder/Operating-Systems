#include <stdio.h>
#include <pthread.h>

void *printHello(void *X)
{
    printf("Hello from thread %ld\n", (long)X);
    pthread_exit(NULL);
}

int main()
{
    long noOfThreads = 5;
    pthread_t thread[noOfThreads];
    for (long i = 0; i < noOfThreads; i++)
    {
        pthread_create(&thread[i], NULL, printHello, (void *)i);
        pthread_join(thread[i], NULL);
    }
}
