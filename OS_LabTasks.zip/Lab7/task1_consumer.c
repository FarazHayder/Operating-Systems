#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

int main()
{
    int fd;
    char *fifo = "/tmp/myFifo";
    char message[100];

    fd = open(fifo, O_RDONLY);
    if (fd == -1)
    {
        perror("Error opening the FIFO for reading");
        exit(EXIT_FAILURE);
    }
    while (1)
    {
        if (read(fd, message, sizeof(message)) > 0)
        {
            printf("Consumer received: %s\n", message);
        }
    }
    close(fd);

    return 0;
}
