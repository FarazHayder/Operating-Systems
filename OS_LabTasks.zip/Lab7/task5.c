#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>

#define BUFFER_SIZE 100

int main()
{
    int pipefd[2];
    pid_t pid;
    char buffer[BUFFER_SIZE];

    if (pipe(pipefd) == -1)
    {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    pid = fork();
    if (pid < 0)
    {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid > 0)
    {
        close(pipefd[0]);
        printf("Parent is sleeping for 5 seconds before writing to the pipe...\n");
        sleep(5);
        const char *message = "Hello from the parent!";
        write(pipefd[1], message, strlen(message) + 1);
        printf("Parent sent: %s\n", message);
        close(pipefd[1]);
        wait(NULL);
    }
    else
    {
        close(pipefd[1]);
        printf("Child is trying to read from the pipe...\n");
        ssize_t bytes_read = read(pipefd[0], buffer, sizeof(buffer));
        if (bytes_read > 0)
        {
            printf("Child received: %s\n", buffer);
        }
        else
        {
            perror("read");
            exit(EXIT_FAILURE);
        }
        close(pipefd[0]);
    }

    return 0;
}