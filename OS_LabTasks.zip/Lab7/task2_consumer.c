#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <errno.h>

int main()
{
    int fd;
    char *fifo = "/tmp/myFifo";
    char buffer[100];
    ssize_t bytes_read;

    fd = open(fifo, O_RDONLY | O_NONBLOCK);
    if (fd == -1)
    {
        perror("Error opening FIFO for reading (Ensure the producer created it)");
        exit(EXIT_FAILURE);
    }

    while (1)
    {
        bytes_read = read(fd, buffer, sizeof(buffer) - 1);

        if (bytes_read == -1)
        {
            if (errno == EAGAIN || errno == EWOULDBLOCK)
            {
                printf("No data available, trying again...\n");
                sleep(1);
            }
            else
            {
                perror("Error reading from FIFO");
                close(fd);
                exit(EXIT_FAILURE);
            }
        }
        else if (bytes_read > 0)
        {
            buffer[bytes_read] = '\0';
            printf("Received: %s\n", buffer);
        }

        sleep(1);
    }

    close(fd);

    return 0;
}
