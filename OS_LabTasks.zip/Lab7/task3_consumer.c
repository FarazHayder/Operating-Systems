#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <errno.h>

#define MAX_PRODUCERS 5

int main()
{
    int fds[MAX_PRODUCERS];
    char fifo[30];
    char buffer[100];
    ssize_t bytes_read;

    for (int i = 0; i < MAX_PRODUCERS; i++)
    {
        snprintf(fifo, sizeof(fifo), "/tmp/myFifo_%d", i + 1);
        fds[i] = open(fifo, O_RDONLY | O_NONBLOCK);
        if (fds[i] == -1)
        {
            if (errno == ENOENT)
            {
                printf("FIFO %s does not exist. Make sure the producer is running.\n", fifo);
                continue;
            }
            else
            {
                perror("Error opening FIFO for reading");
                exit(EXIT_FAILURE);
            }
        }
    }

    while (1)
    {
        for (int i = 0; i < MAX_PRODUCERS; i++)
        {
            if (fds[i] == -1)
                continue;
            bytes_read = read(fds[i], buffer, sizeof(buffer) - 1);
            if (bytes_read == -1)
            {
                if (errno == EAGAIN || errno == EWOULDBLOCK)
                {
                    continue;
                }
                else
                {
                    perror("Error reading from FIFO");
                    exit(EXIT_FAILURE);
                }
            }
            else if (bytes_read > 0)
            {
                buffer[bytes_read] = '\0';
                printf("Received: %s\n", buffer);
                FILE *log_file = fopen("data_log.txt", "a");
                if (log_file != NULL)
                {
                    fprintf(log_file, "Received: %s\n", buffer);
                    fclose(log_file);
                }
                else
                {
                    perror("Error opening log file");
                }
            }
        }
        sleep(1);
    }

    for (int i = 0; i < MAX_PRODUCERS; i++)
    {
        if (fds[i] != -1)
        {
            close(fds[i]);
        }
    }

    return 0;
}
