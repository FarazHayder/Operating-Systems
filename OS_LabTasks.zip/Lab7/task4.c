#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>
#include <errno.h>

#define FIFO_NAME "/tmp/myfifo"
#define BUFFER_SIZE 256

void parent_process()
{
    int fd;
    fd = open(FIFO_NAME, O_WRONLY | O_NONBLOCK);
    if (fd == -1)
    {
        perror("Parent: open");
        exit(1);
    }
    printf("Parent: Writing message 1\n");
    write(fd, "message 1", 9);
    printf("Parent: Writing message 2\n");
    write(fd, "message 2", 9);
    close(fd);
}

void child_process()
{
    int fd;
    char buffer[BUFFER_SIZE];
    ssize_t bytes_read;
    fd = open(FIFO_NAME, O_RDONLY);
    if (fd == -1)
    {
        perror("Child: open");
        exit(1);
    }
    bytes_read = read(fd, buffer, BUFFER_SIZE);
    if (bytes_read > 0)
    {
        buffer[bytes_read] = '\0';
        printf("Child: Read '%s'\n", buffer);
    }
    bytes_read = read(fd, buffer, BUFFER_SIZE);
    if (bytes_read > 0)
    {
        buffer[bytes_read] = '\0';
        printf("Child: Read '%s'\n", buffer);
    }
    close(fd);
}

int main()
{
    pid_t pid;
    if (mkfifo(FIFO_NAME, 0666) == -1)
    {
        if (errno != EEXIST)
        {
            perror("mkfifo");
            exit(1);
        }
    }
    pid = fork();
    if (pid == -1)
    {
        perror("fork");
        exit(1);
    }
    else if (pid > 0)
    {
        parent_process();
    }
    else
    {
        child_process();
    }
    return 0;
}