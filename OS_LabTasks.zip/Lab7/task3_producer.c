#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <signal.h>

int fd;
char fifo[30];

void cleanup(int signum)
{
    printf("\nCaught signal %d, cleaning up...\n", signum);
    close(fd);
    unlink(fifo);
    exit(0);
}

int main(int argc, char *argv[])
{
    char message[100];
    int count = 0;

    if (argc < 2)
    {
        fprintf(stderr, "Usage: %s <producer_id>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    snprintf(fifo, sizeof(fifo), "/tmp/myFifo_%s", argv[1]);

    signal(SIGINT, cleanup);

    if (mkfifo(fifo, 0666) == -1)
    {
        perror("Error creating FIFO");
        exit(EXIT_FAILURE);
    }

    fd = open(fifo, O_WRONLY);
    if (fd == -1)
    {
        perror("Error opening the FIFO for writing");
        exit(EXIT_FAILURE);
    }

    while (1)
    {
        snprintf(message, sizeof(message), "Message %d from producer %s", ++count, argv[1]);
        write(fd, message, strlen(message) + 1);
        printf("Producer %s sent: %s\n", argv[1], message);
        sleep(2);
    }

    return 0;
}
