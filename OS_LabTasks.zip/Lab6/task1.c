#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

int main()
{
    // Opening file in read-only
    int fd = open("inputFile.txt", O_RDONLY);
    if (fd == -1)
    {
        printf("Failed to open the file.\n");
        return 1;
    }

    char buffer[5000];
    ssize_t bytesRead = read(fd, buffer, sizeof(buffer) - 1);
    if (bytesRead == -1)
    {
        printf("Failed to read from the file.\n");
        close(fd);
        return 1;
    }

    printf("Data read successfully.\n");

    buffer[bytesRead] = '\0';
    close(fd);

    // Opening file to write in it
    int fd1 = open("outputFile.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd1 == -1)
    {
        printf("Failed to open the file.\n");
        return 1;
    }

    ssize_t bytesWritten = write(fd1, buffer, bytesRead);
    if (bytesWritten == -1)
    {
        printf("Failed to write to the file.\n");
        close(fd1);
        return 1;
    }

    printf("Data written successfully.\n");

    close(fd1);
    return 0;
}