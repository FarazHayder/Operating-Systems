#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main()
{
    int num_children = 3;
    int pipes[num_children][2]; // Create pipes for each child
    pid_t pids[num_children];   // Array to hold child process IDs
    int numbers[] = {2, 3, 4};  // Numbers for which square will be computed

    // Create pipes for each child
    for (int i = 0; i < num_children; i++)
    {
        if (pipe(pipes[i]) == -1)
        {
            perror("Error creating pipe");
            exit(1);
        }
    }

    // Create child processes
    for (int i = 0; i < num_children; i++)
    {
        pids[i] = fork();

        if (pids[i] == -1)
        {
            perror("Error creating child process");
            exit(2);
        }

        if (pids[i] == 0)
        {                       // Child process
            close(pipes[i][0]); // Close read end of the pipe in child

            int result = numbers[i] * numbers[i];        // Compute square
            write(pipes[i][1], &result, sizeof(result)); // Send result to parent
            close(pipes[i][1]);                          // Close write end after sending

            exit(0); // Child exits after writing
        }
    }

    // Parent process collects results
    for (int i = 0; i < num_children; i++)
    {
        close(pipes[i][1]); // Close write end of the pipe in parent

        int result;
        read(pipes[i][0], &result, sizeof(result)); // Read result from child
        printf("Parent received result from child %d: %d (square of %d)\n", i + 1, result, numbers[i]);

        close(pipes[i][0]); // Close read end after reading
    }

    // Wait for all child processes to finish
    for (int i = 0; i < num_children; i++)
    {
        wait(NULL);
    }

    return 0;
}
