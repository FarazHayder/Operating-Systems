#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main()
{
    int pipefd[2];
    pid_t pid;

    if (pipe(pipefd) == -1)
    {
        perror("pipe");
        exit(1);
    }

    pid = fork();

    if (pid == -1)
    {
        perror("fork");
        exit(1);
    }
    else if (pid == 0)
    {                     // Child process
        close(pipefd[0]); // Close unused read end

        // Redirect stdout to the write end of the pipe
        if (dup2(pipefd[1], STDOUT_FILENO) == -1)
        {
            perror("dup2");
            exit(1);
        }

        printf("Message from child");
        exit(0);
    }
    else
    {                     // Parent process
        close(pipefd[1]); // Close unused write end

        char buffer[100];
        ssize_t bytes_read = read(pipefd[0], buffer, sizeof(buffer) - 1);

        if (bytes_read > 0)
        {
            buffer[bytes_read] = '\0'; // Null-terminate the string
            printf("Parent received: %s\n", buffer);
        }
        else if (bytes_read == -1)
        {
            perror("read");
        }

        wait(NULL); // Wait for child to finish
        close(pipefd[0]);
    }

    return 0;
}