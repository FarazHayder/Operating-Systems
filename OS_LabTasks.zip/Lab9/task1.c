#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

int main()
{
    int fd = open("output.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd == -1)
    {
        perror("open");
        exit(1);
    }

    int fd_dup = dup(fd);
    if (fd_dup == -1)
    {
        perror("dup");
        exit(1);
    }

    if (dup2(fd_dup, STDOUT_FILENO) == -1)
    {
        perror("dup2");
        exit(1);
    }

    printf("Hello world\n");

    close(fd);
    close(fd_dup);

    return 0;
}