#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

int main()
{
    int fd = open("input.txt", O_RDONLY);
    if (fd == -1)
    {
        perror("open");
        exit(1);
    }

    if (dup2(fd, STDIN_FILENO) == -1)
    {
        perror("dup2");
        exit(1);
    }

    char buffer[100];
    if (fgets(buffer, sizeof(buffer), stdin) != NULL)
    {
        printf("Read from file: %s", buffer);
    }
    else
    {
        perror("fgets");
    }

    close(fd);

    return 0;
}