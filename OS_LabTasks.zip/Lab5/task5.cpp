#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <cstdlib>
#include <ctime>

using namespace std;

bool isPrime(int num)
{
    if (num <= 1)
        return false;
    for (int i = 2; i * i <= num; i++)
    {
        if (num % i == 0)
            return false;
    }
    return true;
}

int countPrimes(int arr[], int start, int end)
{
    int primeCount = 0;
    for (int i = start; i < end; i++)
    {
        if (isPrime(arr[i]))
        {
            primeCount++;
        }
    }
    return primeCount;
}

int main()
{
    const int SIZE = 1000;
    int arr[SIZE];
    srand(time(0));

    for (int i = 0; i < SIZE; i++)
    {
        arr[i] = rand() % 100 + 1;
    }

    pid_t pid1 = fork();

    if (pid1 < 0)
    {
        cerr << "Fork failed for first child process!\n";
        return 1;
    }
    else if (pid1 == 0)
    {
        int primesInFirstHalf = countPrimes(arr, 0, 500);
        cout << "Child 1: Number of prime numbers in the first half = " << primesInFirstHalf << endl;
        exit(0);
    }

    pid_t pid2 = fork();

    if (pid2 < 0)
    {
        cerr << "Fork failed for second child process!\n";
        return 1;
    }
    else if (pid2 == 0)
    {
        int primesInSecondHalf = countPrimes(arr, 500, 1000);
        cout << "Child 2: Number of prime numbers in the second half = " << primesInSecondHalf << endl;
        exit(0);
    }

    wait(NULL);
    wait(NULL);

    return 0;
}
