#include <stdio.h>
#include <unistd.h>
#include <sys/types.h> // For pid_t
#include <stdlib.h>    // For exit

int main()
{
    pid_t pid = fork();
    if (pid < 0)
    {
        printf("Fork Failed!");
    }
    else if (pid == 0)
    {
        printf("Child: pid=%d\n", getpid());
        exit(0);
    }
    else
    {
        sleep(1);
        printf("Parent: child's pid=%d\n", pid);
    }

    return 0;
}