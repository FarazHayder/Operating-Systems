#include <stdio.h>
#include <unistd.h>
#include <sys/types.h> // For pid_t
#include <stdlib.h>    // For exit

int main()
{
    pid_t pid = fork();
    if (pid < 0)
    {
        printf("Fork Failed!");
    }
    else if (pid == 0)
    {
        printf("Parent's pid = %d\n", getppid());
        sleep(1);
        printf("Parent's pid after being adopted = %d\n", getppid());
        printf("Child is terminating.\n");
    }
    else
    {
        printf("Parent is terminating.\n");
    }

    return 0;
}