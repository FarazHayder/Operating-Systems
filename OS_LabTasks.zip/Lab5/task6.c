#include <stdio.h>
#include <unistd.h>

int main()
{
    char *envp[] = {"MY_VAR = HelloWorld", NULL};

    execle("/usr/bin/env", "env", NULL, envp);

    return 0;
}
