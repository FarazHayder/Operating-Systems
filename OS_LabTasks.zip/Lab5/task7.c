#include <stdio.h>
#include <unistd.h>

int main()
{
    char command[100]; // String

    printf("Enter a command to execute: ");
    scanf("%s", command);

    char *args[] = {command, NULL};
    execvp(command, args);

    return 0;
}
