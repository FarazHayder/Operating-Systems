#include <stdio.h>
#include <unistd.h>
#include <sys/types.h> // For pid_t
#include <stdlib.h>    // For exit()
#include <sys/wait.h>  // For wait()

int main()
{
    pid_t pid = fork();
    if (pid < 0)
    {
        printf("Fork Failed!");
    }
    else if (pid == 0)
    {
        int age = 0;
        printf("Please enter your age: ");
        scanf("%d", &age);
        exit(age);
    }
    else
    {
        int status;
        wait(&status);
        int age = WEXITSTATUS(status);
        printf("Your age is = %d\n", age);
    }

    return 0;
}