#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <errno.h>
#include <string.h>

// Global mutexes
pthread_mutex_t mutex1 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutex2 = PTHREAD_MUTEX_INITIALIZER;

// Function to demonstrate deadlock
void *thread1_deadlock(void *arg)
{
    printf("Thread 1: Starting\n");
    printf("Thread 1: Attempting to lock mutex1\n");
    pthread_mutex_lock(&mutex1);
    printf("Thread 1: Locked mutex1\n");

    // Sleep to increase chances of deadlock
    sleep(2);

    printf("Thread 1: Attempting to lock mutex2\n");
    pthread_mutex_lock(&mutex2);
    printf("Thread 1: Locked mutex2\n");

    // Critical section
    printf("Thread 1: In critical section\n");

    // Unlock mutexes
    pthread_mutex_unlock(&mutex2);
    pthread_mutex_unlock(&mutex1);

    return NULL;
}

void *thread2_deadlock(void *arg)
{
    printf("Thread 2: Starting\n");
    printf("Thread 2: Attempting to lock mutex2\n");
    pthread_mutex_lock(&mutex2);
    printf("Thread 2: Locked mutex2\n");

    // Sleep to increase chances of deadlock
    sleep(1);

    printf("Thread 2: Attempting to lock mutex1\n");
    pthread_mutex_lock(&mutex1);
    printf("Thread 2: Locked mutex1\n");

    // Critical section
    printf("Thread 2: In critical section\n");

    // Unlock mutexes
    pthread_mutex_unlock(&mutex1);
    pthread_mutex_unlock(&mutex2);

    return NULL;
}

// Function with timeout-based deadlock prevention
void *thread1_safe(void *arg)
{
    struct timespec timeout;
    int retry_count = 0;
    const int MAX_RETRIES = 3;

    while (retry_count < MAX_RETRIES)
    {
        printf("Thread 1: Starting attempt %d\n", retry_count + 1);

        // Try to lock mutex1
        printf("Thread 1: Attempting to lock mutex1\n");
        if (pthread_mutex_lock(&mutex1) != 0)
        {
            printf("Thread 1: Failed to lock mutex1\n");
            sleep(1);
            retry_count++;
            continue;
        }
        printf("Thread 1: Locked mutex1\n");

        // Set timeout for 2 seconds from now
        clock_gettime(CLOCK_REALTIME, &timeout);
        timeout.tv_sec += 2;

        // Try to lock mutex2 with timeout
        printf("Thread 1: Attempting to lock mutex2 with timeout\n");
        int result = pthread_mutex_timedlock(&mutex2, &timeout);

        if (result == ETIMEDOUT)
        {
            printf("Thread 1: Timeout trying to lock mutex2. Releasing mutex1 and retrying...\n");
            pthread_mutex_unlock(&mutex1);
            sleep(1);
            retry_count++;
            continue;
        }
        else if (result == 0)
        {
            // Successfully locked both mutexes
            printf("Thread 1: Locked mutex2\n");
            printf("Thread 1: In critical section\n");
            sleep(1);

            // Unlock mutexes
            pthread_mutex_unlock(&mutex2);
            pthread_mutex_unlock(&mutex1);
            printf("Thread 1: Released all locks\n");
            return NULL;
        }
    }

    printf("Thread 1: Max retries reached, giving up\n");
    return NULL;
}

void *thread2_safe(void *arg)
{
    struct timespec timeout;
    int retry_count = 0;
    const int MAX_RETRIES = 3;

    while (retry_count < MAX_RETRIES)
    {
        printf("Thread 2: Starting attempt %d\n", retry_count + 1);

        // Try to lock mutex2
        printf("Thread 2: Attempting to lock mutex2\n");
        if (pthread_mutex_lock(&mutex2) != 0)
        {
            printf("Thread 2: Failed to lock mutex2\n");
            sleep(1);
            retry_count++;
            continue;
        }
        printf("Thread 2: Locked mutex2\n");

        // Set timeout for 2 seconds from now
        clock_gettime(CLOCK_REALTIME, &timeout);
        timeout.tv_sec += 2;

        // Try to lock mutex1 with timeout
        printf("Thread 2: Attempting to lock mutex1 with timeout\n");
        int result = pthread_mutex_timedlock(&mutex1, &timeout);

        if (result == ETIMEDOUT)
        {
            printf("Thread 2: Timeout trying to lock mutex1. Releasing mutex2 and retrying...\n");
            pthread_mutex_unlock(&mutex2);
            sleep(1);
            retry_count++;
            continue;
        }
        else if (result == 0)
        {
            // Successfully locked both mutexes
            printf("Thread 2: Locked mutex1\n");
            printf("Thread 2: In critical section\n");
            sleep(1);

            // Unlock mutexes
            pthread_mutex_unlock(&mutex1);
            pthread_mutex_unlock(&mutex2);
            printf("Thread 2: Released all locks\n");
            return NULL;
        }
    }

    printf("Thread 2: Max retries reached, giving up\n");
    return NULL;
}

int main()
{
    pthread_t thread1, thread2;

    printf("\n=== Demonstrating Deadlock Scenario ===\n");
    printf("This will get stuck in a deadlock. Wait a few seconds, then press Ctrl+C\n\n");

    // Create threads that will deadlock
    pthread_create(&thread1, NULL, thread1_deadlock, NULL);
    pthread_create(&thread2, NULL, thread2_deadlock, NULL);

    // Wait for deadlock to occur
    sleep(5);

    // Force terminate threads
    pthread_cancel(thread1);
    pthread_cancel(thread2);

    // Reset mutexes
    pthread_mutex_destroy(&mutex1);
    pthread_mutex_destroy(&mutex2);
    pthread_mutex_init(&mutex1, NULL);
    pthread_mutex_init(&mutex2, NULL);

    printf("\n=== Demonstrating Deadlock Prevention with Timeouts ===\n\n");

    // Create threads with deadlock prevention
    pthread_create(&thread1, NULL, thread1_safe, NULL);
    pthread_create(&thread2, NULL, thread2_safe, NULL);

    // Wait for threads to complete
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    // Cleanup
    pthread_mutex_destroy(&mutex1);
    pthread_mutex_destroy(&mutex2);

    printf("\nProgram completed successfully\n");
    return 0;
}
