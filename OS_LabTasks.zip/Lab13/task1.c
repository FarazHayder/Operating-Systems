#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>

// Shared resource
struct BankAccount
{
    double balance;
    pthread_mutex_t mutex;
};

// Global bank account
struct BankAccount account;

// Function prototypes
void *perform_transactions(void *arg);
void deposit(struct BankAccount *account, double amount);
void withdraw(struct BankAccount *account, double amount);

// Number of threads
#define NUM_THREADS 5

int main()
{
    // Initialize account
    account.balance = 1000.0; // Initial balance

    // Initialize mutex
    if (pthread_mutex_init(&account.mutex, NULL) != 0)
    {
        printf("Mutex initialization failed\n");
        return 1;
    }

    // Create multiple threads
    pthread_t threads[NUM_THREADS];
    int i;

    // Start threads
    for (i = 0; i < NUM_THREADS; i++)
    {
        int *thread_id = malloc(sizeof(int));
        *thread_id = i;
        if (pthread_create(&threads[i], NULL, perform_transactions, thread_id) != 0)
        {
            printf("Thread creation failed\n");
            return 1;
        }
    }

    // Wait for all threads to complete
    for (i = 0; i < NUM_THREADS; i++)
    {
        pthread_join(threads[i], NULL);
    }

    // Destroy mutex
    pthread_mutex_destroy(&account.mutex);

    printf("Final balance: $%.2f\n", account.balance);
    return 0;
}

void *perform_transactions(void *arg)
{
    int thread_id = *(int *)arg;
    free(arg); // Free allocated memory

    // Deposit
    double amount = (rand() % 100) + 1; // Random amount between 1 and 100
    deposit(&account, amount);
    printf("Thread %d deposited $%.2f\n", thread_id, amount);

    // Withdraw
    amount = (rand() % 50) + 1; // Random amount between 1 and 50
    withdraw(&account, amount);
    printf("Thread %d withdrew $%.2f\n", thread_id, amount);

    return NULL;
}

void deposit(struct BankAccount *account, double amount)
{
    pthread_mutex_lock(&account->mutex);

    // Critical section
    double new_balance = account->balance + amount;
    usleep(1000); // Simulate some processing time
    account->balance = new_balance;

    pthread_mutex_unlock(&account->mutex);
}

void withdraw(struct BankAccount *account, double amount)
{
    pthread_mutex_lock(&account->mutex);

    // Critical section
    if (account->balance >= amount)
    {
        double new_balance = account->balance - amount;
        usleep(1000); // Simulate some processing time
        account->balance = new_balance;
    }
    else
    {
        printf("Insufficient funds for withdrawal of $%.2f (Current balance: $%.2f)\n",
               amount, account->balance);
    }

    pthread_mutex_unlock(&account->mutex);
}
