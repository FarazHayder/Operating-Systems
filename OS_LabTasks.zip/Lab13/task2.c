#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>

struct Account
{
    int id;
    double balance;
    pthread_mutex_t mutex;
};

// Global accounts
struct Account account1;
struct Account account2;

// Function to demonstrate deadlock
void *transfer_deadlock(void *arg)
{
    int thread_id = *(int *)arg;
    double amount = 50.0;

    while (1)
    {
        if (thread_id == 1)
        {
            // Thread 1 tries to transfer from account1 to account2
            printf("Thread 1: Attempting to lock account1\n");
            pthread_mutex_lock(&account1.mutex);
            printf("Thread 1: Locked account1\n");

            // Simulate some processing time
            sleep(1);

            printf("Thread 1: Attempting to lock account2\n");
            pthread_mutex_lock(&account2.mutex);
            printf("Thread 1: Locked account2\n");

            // Perform transfer
            if (account1.balance >= amount)
            {
                account1.balance -= amount;
                account2.balance += amount;
                printf("Thread 1: Transferred $%.2f from Account 1 to Account 2\n", amount);
            }

            pthread_mutex_unlock(&account2.mutex);
            pthread_mutex_unlock(&account1.mutex);
        }
        else
        {
            // Thread 2 tries to transfer from account2 to account1
            printf("Thread 2: Attempting to lock account2\n");
            pthread_mutex_lock(&account2.mutex);
            printf("Thread 2: Locked account2\n");

            // Simulate some processing time
            sleep(1);

            printf("Thread 2: Attempting to lock account1\n");
            pthread_mutex_lock(&account1.mutex);
            printf("Thread 2: Locked account1\n");

            // Perform transfer
            if (account2.balance >= amount)
            {
                account2.balance -= amount;
                account1.balance += amount;
                printf("Thread 2: Transferred $%.2f from Account 2 to Account 1\n", amount);
            }

            pthread_mutex_unlock(&account1.mutex);
            pthread_mutex_unlock(&account2.mutex);
        }
    }
    return NULL;
}

// Function with deadlock prevention
void *transfer_safe(void *arg)
{
    int thread_id = *(int *)arg;
    double amount = 50.0;

    while (1)
    {
        struct Account *first_account, *second_account;

        // Always lock accounts in order of their ID
        if (account1.id < account2.id)
        {
            first_account = &account1;
            second_account = &account2;
        }
        else
        {
            first_account = &account2;
            second_account = &account1;
        }

        // Lock accounts in consistent order
        pthread_mutex_lock(&first_account->mutex);
        pthread_mutex_lock(&second_account->mutex);

        if (thread_id == 1)
        {
            // Transfer from account1 to account2
            if (account1.balance >= amount)
            {
                account1.balance -= amount;
                account2.balance += amount;
                printf("Thread 1: Safely transferred $%.2f from Account 1 to Account 2\n", amount);
                printf("Account 1 balance: $%.2f, Account 2 balance: $%.2f\n",
                       account1.balance, account2.balance);
            }
        }
        else
        {
            // Transfer from account2 to account1
            if (account2.balance >= amount)
            {
                account2.balance -= amount;
                account1.balance += amount;
                printf("Thread 2: Safely transferred $%.2f from Account 2 to Account 1\n", amount);
                printf("Account 1 balance: $%.2f, Account 2 balance: $%.2f\n",
                       account1.balance, account2.balance);
            }
        }

        // Release locks in reverse order
        pthread_mutex_unlock(&second_account->mutex);
        pthread_mutex_unlock(&first_account->mutex);

        // Sleep to make output readable
        sleep(1);
    }
    return NULL;
}

int main()
{
    // Initialize accounts
    account1.id = 1;
    account1.balance = 1000.0;
    account2.id = 2;
    account2.balance = 1000.0;

    pthread_mutex_init(&account1.mutex, NULL);
    pthread_mutex_init(&account2.mutex, NULL);

    pthread_t thread1, thread2;
    int id1 = 1, id2 = 2;

    // Deadlock Scenario
    printf("\n=== Demonstrating Deadlock Scenario ===\n");
    // Create threads that will demonstrate deadlock
    pthread_create(&thread1, NULL, transfer_deadlock, &id1);
    pthread_create(&thread2, NULL, transfer_deadlock, &id2);
    // Wait for a few seconds to demonstrate deadlock
    sleep(2);
    // Force terminate threads (in real code, you'd want to do this more gracefully)
    pthread_cancel(thread1);
    pthread_cancel(thread2);

    // Deadlock Prevention Scenario
    printf("\n=== Demonstrating Deadlock Prevention ===\n\n");
    // Reset account balances
    account1.balance = 1000.0;
    account2.balance = 1000.0;
    // Create threads with deadlock prevention
    pthread_create(&thread1, NULL, transfer_safe, &id1);
    pthread_create(&thread2, NULL, transfer_safe, &id2);
    // Let the safe transfers run for a while
    sleep(2);

    // Cleanup
    pthread_cancel(thread1);
    pthread_cancel(thread2);
    pthread_mutex_destroy(&account1.mutex);
    pthread_mutex_destroy(&account2.mutex);

    return 0;
}
