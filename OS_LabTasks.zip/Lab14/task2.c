#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

// Shared data
int shared_number;
sem_t semaphore;

// Producer function
void *producer(void *arg)
{
    while (1)
    {
        // Generate random number between 1-100
        shared_number = rand() % 100 + 1;
        printf("Producer: Generated number %d\n", shared_number);

        // Signal consumer that data is ready
        sem_post(&semaphore);

        // Add small delay
        sleep(1);
    }
    return NULL;
}

// Consumer function
void *consumer(void *arg)
{
    while (1)
    {
        // Wait for producer to signal data is ready
        sem_wait(&semaphore);

        // Consume the number
        printf("Consumer: Consumed number %d\n", shared_number);
    }
    return NULL;
}

int main()
{
    // Initialize random seed
    srand(time(NULL));

    // Initialize binary semaphore
    sem_init(&semaphore, 0, 0);

    // Create producer and consumer threads
    pthread_t producer_thread, consumer_thread;
    pthread_create(&producer_thread, NULL, producer, NULL);
    pthread_create(&consumer_thread, NULL, consumer, NULL);

    // Wait for threads to finish (they won't in this case)
    pthread_join(producer_thread, NULL);
    pthread_join(consumer_thread, NULL);

    // Cleanup
    sem_destroy(&semaphore);

    return 0;
}
