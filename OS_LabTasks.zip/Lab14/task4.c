#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <limits.h>

#define ARRAY_SIZE 1000
#define NUM_THREADS 4

// Shared variables
int array[ARRAY_SIZE];
int global_min = INT_MAX;
sem_t min_semaphore;

// Structure to pass data to threads
typedef struct
{
    int start_index;
    int end_index;
} ThreadData;

void *find_min(void *arg)
{
    ThreadData *data = (ThreadData *)arg;
    int local_min = INT_MAX;

    // Find minimum in this thread's segment
    for (int i = data->start_index; i < data->end_index; i++)
    {
        if (array[i] < local_min)
        {
            local_min = array[i];
        }
    }

    // Update global minimum if local minimum is smaller
    sem_wait(&min_semaphore);
    if (local_min < global_min)
    {
        global_min = local_min;
    }
    sem_post(&min_semaphore);

    free(arg);
    return NULL;
}

int main()
{
    pthread_t threads[NUM_THREADS];

    // Initialize semaphore
    sem_init(&min_semaphore, 0, 1);

    // Initialize array with random values
    for (int i = 0; i < ARRAY_SIZE; i++)
    {
        array[i] = rand() % 10000;
    }

    // Create threads
    int segment_size = ARRAY_SIZE / NUM_THREADS;
    for (int i = 0; i < NUM_THREADS; i++)
    {
        ThreadData *data = malloc(sizeof(ThreadData));
        data->start_index = i * segment_size;
        data->end_index = (i == NUM_THREADS - 1) ? ARRAY_SIZE : (i + 1) * segment_size;

        pthread_create(&threads[i], NULL, find_min, data);
    }

    // Wait for all threads to complete
    for (int i = 0; i < NUM_THREADS; i++)
    {
        pthread_join(threads[i], NULL);
    }

    // Print result
    printf("The minimum value in the array is: %d\n", global_min);

    // Cleanup
    sem_destroy(&min_semaphore);

    return 0;
}
