#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

#define ARRAY_SIZE 100
#define NUM_THREADS 4

// Shared variables
int array[ARRAY_SIZE];
long total_sum = 0;
sem_t semaphore;

// Structure to pass data to threads
typedef struct
{
    int start_index;
    int end_index;
} ThreadData;

// Thread function
void *calculate_partial_sum(void *arg)
{
    ThreadData *data = (ThreadData *)arg;
    long partial_sum = 0;

    // Calculate partial sum for the assigned segment
    for (int i = data->start_index; i < data->end_index; i++)
    {
        partial_sum += array[i];
    }

    // Use semaphore to protect the critical section
    sem_wait(&semaphore);
    total_sum += partial_sum; // Critical section
    sem_post(&semaphore);

    free(arg);
    pthread_exit(NULL);
}

int main()
{
    pthread_t threads[NUM_THREADS];

    // Initialize the semaphore
    sem_init(&semaphore, 0, 1);

    // Initialize array with values 1 to ARRAY_SIZE
    for (int i = 0; i < ARRAY_SIZE; i++)
    {
        array[i] = i + 1;
    }

    // Create threads
    int segment_size = ARRAY_SIZE / NUM_THREADS;
    for (int i = 0; i < NUM_THREADS; i++)
    {
        ThreadData *data = malloc(sizeof(ThreadData));
        data->start_index = i * segment_size;
        data->end_index = (i == NUM_THREADS - 1) ? ARRAY_SIZE : (i + 1) * segment_size;

        pthread_create(&threads[i], NULL, calculate_partial_sum, (void *)data);
    }

    // Wait for all threads to complete
    for (int i = 0; i < NUM_THREADS; i++)
    {
        pthread_join(threads[i], NULL);
    }

    // Destroy the semaphore
    sem_destroy(&semaphore);

    // Print the final sum
    printf("Total sum: %ld\n", total_sum);

    return 0;
}
