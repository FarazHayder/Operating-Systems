#include <stdio.h>
#include <unistd.h>    // for getpid() and getppid()
#include <sys/types.h> // for pid_t

int GLOBAL_VARIABLE = 0;

int main()
{
    pid_t pid = fork();

    if (pid == -1)
    {
        printf("Fork Failed.\n");
        return 1;
    }
    if (pid == 0)
    {
        GLOBAL_VARIABLE += 5;
        printf("Child 1: PID = %d, PPID = %d\n", getpid(), getppid());

        pid_t pid1 = fork();
        if (pid1 == -1)
        {
            printf("Fork Failed.\n");
            return 1;
        }
        if (pid1 == 0)
        {
            printf("Child 2: PID = %d, PPID = %d\n", getpid(), getppid());
        }
        else
        {
            sleep(1);
            printf("Parent: Child 1 PID = %d\n", getpid());
        }
    }
    else
    {
        sleep(1);
        printf("Parent: PID = %d\n", getpid());
    }

    return 0;
}