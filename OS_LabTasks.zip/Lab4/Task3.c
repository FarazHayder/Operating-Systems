#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main()
{
    for (int i = 1; i < 4; i++)
    {
        pid_t pid = fork();
        if (pid == -1)
        {
            printf("Fork Failed.\n");
            return 1;
        }
        if (pid == 0)
        {
            printf("Child %d: PID = %d, Parent PID = %d\n", i, getpid(), getppid());
            int sum = 5 + 5;
            printf("Child %d: Task completed, sum = %d\n", i, sum);
            _exit(0);
        }
        else
        {
            wait(NULL);
            printf("Parent: Child %d (PID = %d) has completed.\n", i, pid);
        }
    }
    printf("Parent: All children have terminated.\n");
    return 0;
}