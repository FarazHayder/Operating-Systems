#include <stdio.h>
#include <unistd.h>    // for getpid() and getppid()
#include <sys/types.h> // for pid_t
#include <sys/wait.h>

int GLOBAL_VARIABLE = 0;

int main()
{
    pid_t pid = fork();

    if (pid == -1)
    {
        printf("Fork Failed.\n");
        return 1;
    }
    if (pid == 0)
    {
        GLOBAL_VARIABLE += 5;
        printf("Child 1: Global variable = %d\n", GLOBAL_VARIABLE);

        pid_t pid1 = fork();
        if (pid1 == -1)
        {
            printf("Fork Failed.\n");
            return 1;
        }
        if (pid1 == 0)
        {
            GLOBAL_VARIABLE += 5;
            printf("Child 2: Global variable = %d\n", GLOBAL_VARIABLE);
        }
    }
    else
    {
        sleep(1);
        printf("Parent: Final global variable = %d\n", GLOBAL_VARIABLE);
    }

    return 0;
}