/*
<========== LUDO GAME ==========>
This project is the ownership of the creators (mentioned below) and is not to be copied by anyone else.
© Copyrights Reserved - Faraz Hayder LUDO GAME
Owners:-
    Faraz Hayder - I222687
 */

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <limits>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#include <chrono>

using namespace std;

#define RESET "\u001B[0m" // Resets the color to original console color, otherwise the color would have remained to the changed color
#define RED "\u001B[0;101m"
#define GREEN "\u001B[0;102m"
#define YELLOW "\u001B[0;103m"
#define BLUE "\u001B[0;104m"
#define CYAN "\u001B[0;106m"
#define MAGENTA "\u001B[0;105m"
#define WHITE "\u001B[47m"
#define GRAY "\u001B[0;100m"

#define SIZE 11
#define PATH_CELLS 40 // Path Cells: These represent the number of cells which are actually the path.
#define MAX_PLAYERS 4
#define MAX_TOKENS 4
#define MAX_DICE_COUNT 6

int num_tokens = 0; // Global variable to store the number of tokens per player

// Safe squares on the board where players cannot be hit
const int safe_cells[] = {0, 5, 10, 15, 20, 25, 30, 35};

class Cell
{
public:
    int x;     // X-coordinate position on the board
    int y;     // Y-coordinate position on the board
    int value; // Value stored in the cell (used for house positions and path identification)
};

class Player
{
public:
    int x;     // Current X-coordinate position on the board
    int y;     // Current Y-coordinate position on the board
    int team;  // Player's team number (0=Red, 1=Green, 2=Blue, 3=Yellow)
    int index; // Position in the path (-1=in house, 0-39=on path, 100+=in final stretch)
    int id;    // Token identifier (1-4) for each player's pieces
};

char board[SIZE][SIZE];
Cell cells[PATH_CELLS];
Cell houses[MAX_PLAYERS][MAX_TOKENS];
Player players[MAX_PLAYERS][MAX_TOKENS];
sem_t dice_semaphore;
pthread_mutex_t board_mutex;
pthread_cond_t turn_cond;
bool game_over = false;
int current_turn = 0;
int num_players;
int finished_positions[MAX_PLAYERS] = {0};
int hit_rate[MAX_PLAYERS] = {0};
int consecutive_turns_no_six[MAX_PLAYERS] = {0};

void initializeBoard(char board[SIZE][SIZE])
{
    // Initialize the game board layout where:
    // 'r' = red home area
    // 'g' = green home area
    // 'b' = blue home area
    // 'y' = yellow home area
    // 'O' = path cells
    // 'H' = center home
    // ' ' = Border
    char new_board[SIZE][SIZE] = {
        {'r', 'r', ' ', 'O', 'O', 'O', 'O', 'g', ' ', 'g', 'g'},
        {'r', 'r', ' ', 'S', ' ', 'g', ' ', 'O', ' ', 'g', 'g'},
        {' ', ' ', ' ', 'O', ' ', 'g', ' ', 'O', ' ', ' ', ' '},
        {'r', 'O', 'O', 'O', ' ', 'g', ' ', 'O', 'O', 'S', 'O'},
        {'O', ' ', ' ', ' ', ' ', 'g', ' ', ' ', ' ', ' ', 'O'},
        {'O', 'r', 'r', 'r', 'r', 'H', 'b', 'b', 'b', 'b', 'O'},
        {'O', ' ', ' ', ' ', ' ', 'y', ' ', ' ', ' ', ' ', 'O'},
        {'O', 'S', 'O', 'O', ' ', 'y', ' ', 'O', 'O', 'O', 'b'},
        {' ', ' ', ' ', 'O', ' ', 'y', ' ', 'O', ' ', ' ', ' '},
        {'y', 'y', ' ', 'O', ' ', 'y', ' ', 'S', ' ', 'b', 'b'},
        {'y', 'y', ' ', 'y', 'O', 'O', 'O', 'O', ' ', 'b', 'b'}};

    // Deep copy the initialized board layout to the passed board array
    for (int i = 0; i < SIZE; i++)
    {
        for (int j = 0; j < SIZE; j++)
        {
            board[i][j] = new_board[i][j];
        }
    }
}

void gameInitialization()
{
    // Define the path coordinates that tokens will follow
    // Each pair represents (y,x) coordinates on the board
    // The path forms a complete circuit around the board
    int path_cells[PATH_CELLS][2] = {
        {3, 0}, {3, 1}, {3, 2}, {3, 3}, {2, 3}, {1, 3}, {0, 3}, {0, 4}, {0, 5}, {0, 6}, {0, 7}, {1, 7}, {2, 7}, {3, 7}, {3, 8}, {3, 9}, {3, 10}, {4, 10}, {5, 10}, {6, 10}, {7, 10}, {7, 9}, {7, 8}, {7, 7}, {8, 7}, {9, 7}, {10, 7}, {10, 6}, {10, 5}, {10, 4}, {10, 3}, {9, 3}, {8, 3}, {7, 3}, {7, 2}, {7, 1}, {7, 0}, {6, 0}, {5, 0}, {4, 0}};

    // Initialize the path cells array with coordinates and default values
    for (int i = 0; i < PATH_CELLS; i++)
    {
        cells[i].y = path_cells[i][0];
        cells[i].x = path_cells[i][1];
        cells[i].value = 0; // Initialize cell value to 0
    }

    // Define the starting house positions for each player's tokens
    // First dimension: player number (0-3)
    // Second dimension: token number (0-3)
    // Third dimension: coordinates (y,x)
    int new_houses[MAX_PLAYERS][MAX_TOKENS][2] = {
        {{0, 0}, {0, 1}, {1, 1}, {1, 0}},
        {{0, 9}, {0, 10}, {1, 10}, {1, 9}},
        {{9, 9}, {9, 10}, {10, 10}, {10, 9}},
        {{9, 0}, {9, 1}, {10, 1}, {10, 0}}};

    // Initialize the house positions for each player
    for (int i = 0; i < MAX_PLAYERS; i++)
    {
        for (int j = 0; j < MAX_TOKENS; j++)
        {
            houses[i][j].y = new_houses[i][j][0];
            houses[i][j].x = new_houses[i][j][1];
            houses[i][j].value = (j + 1) + (i * 10); // Unique ID for each house position
        }
    }

    // Initialize player tokens at their starting house positions
    for (int i = 0; i < MAX_PLAYERS; i++)
    {
        for (int j = 0; j < MAX_TOKENS; j++)
        {
            players[i][j].x = houses[i][j].x;
            players[i][j].y = houses[i][j].y;
            players[i][j].index = -1; // -1 indicates token is in starting house
            players[i][j].team = i;   // Assign team number (0-3)
            players[i][j].id = j + 1; // Assign token ID (1-4)
        }
    }
}

void titleDisplay()
{
    cout << " __________________________________________________________" << endl;
    cout << "|\e[1;31m    __            \e[1;32m   __        \e[1;36m______       \e[1;33m              " << RESET << "|" << endl;
    cout << "|\e[1;31m   / /   __  __ \e[1;32m____/ /___    \e[1;36m/ ____/___ _\e[1;33m____ ___  ___   " << RESET << "|" << endl;
    cout << "|\e[1;31m  / /   / / / / \e[1;32m __  / __ \\ \e[1;36m / / __/ __ `/\e[1;33m __ `__ \\/ _ \\  " << RESET << "|" << endl;
    cout << "|\e[1;31m / /___/ /_/ / \e[1;32m /_/ / /_/ / \e[1;36m/ /_/ / /_/ / \e[1;33m/ / / / /  __/  " << RESET << "|" << endl;
    cout << "|\e[1;31m/_____/\\__,_/ \e[1;32m\\__,_/\\____/\e[1;36m  \\____/\\__,_/\e[1;33m_/ /_/ /_/\\___/   " << RESET << "|" << endl;
    cout << "|__________________________________________________________|" << endl;
}

void display(char board[SIZE][SIZE])
{
    for (int i = 0; i < SIZE; i++)
    {
        for (int j = 0; j < SIZE; j++)
        {
            string s = "";
            s += board[i][j]; // Add the board character
            s += " ";         // Add a space for better visibility
            switch (board[i][j])
            {
            case 'r':
                cout << RED << s << RESET;
                break;
            case 'g':
                cout << GREEN << s << RESET;
                break;
            case 'b':
                cout << CYAN << s << RESET;
                break;
            case 'y':
                cout << YELLOW << s << RESET;
                break;
            case 'S':
                cout << GRAY << s << RESET;
                break;
            case 'H':
                cout << MAGENTA << s << RESET;
                break;
            case ' ':
                cout << WHITE << "  " << RESET;
                break;
            default:
                cout << s;
                break;
            }
        }
        cout << endl;
    }
    cout << endl;
}

void displayCurrent(char board[SIZE][SIZE], Player players[MAX_PLAYERS][MAX_TOKENS])
{
    char current_board[SIZE][SIZE];

    for (int i = 0; i < SIZE; i++)
    {
        for (int j = 0; j < SIZE; j++)
        {
            current_board[i][j] = board[i][j];
        }
    }

    for (int i = 0; i < MAX_PLAYERS; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            if (players[i][j].index != -1)
            {
                current_board[players[i][j].y][players[i][j].x] = '0' + players[i][j].id;
            }
        }
    }

    cout << endl;
    for (int i = 0; i < SIZE; i++)
    {
        for (int j = 0; j < SIZE; j++)
        {
            string s = "";
            s += current_board[i][j];
            s += " ";
            switch (current_board[i][j])
            {
            case 'r':
                s = "O ";
                cout << RED << s << RESET;
                break;
            case 'g':
                s = "O ";
                cout << GREEN << s << RESET;
                break;
            case 'b':
                s = "O ";
                cout << CYAN << s << RESET;
                break;
            case 'y':
                s = "O ";
                cout << YELLOW << s << RESET;
                break;
            case 'S':
                s = "O ";
                cout << GRAY << s << RESET;
                break;
            case '1':
            case '2':
            case '3':
            case '4':
                s = current_board[i][j];
                s += " ";
                for (int a = 0; a < MAX_PLAYERS; a++)
                {
                    for (int b = 0; b < 4; b++)
                    {
                        if (i == players[a][b].y && j == players[a][b].x)
                        {
                            switch (players[a][b].team)
                            {
                            case 0:
                                s = RED + s + RESET;
                                break;
                            case 1:
                                s = GREEN + s + RESET;
                                break;
                            case 2:
                                s = CYAN + s + RESET;
                                break;
                            case 3:
                                s = YELLOW + s + RESET;
                                break;
                            }
                        }
                    }
                }
                cout << s;
                break;
            case 'H':
                cout << MAGENTA << "H " << RESET;
                break;
            case ' ':
                cout << WHITE << "  " << RESET;
                break;
            default:
                cout << s;
                break;
            }
        }
        cout << endl;
    }
    cout << endl;
}

void verifyInput()
{
    if (!cin)
    {
        cout << "\nERROR - Enter a valid number";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "\n";
    }
}

string tokenColor(int id)
{
    switch (id)
    {
    case 0:
        return RED;
    case 1:
        return GREEN;
    case 2:
        return CYAN;
    case 3:
        return YELLOW;
    default:
        return "";
    }
}

int getIndex(int turn)
{
    return turn * 10;
}

bool wayFinal(int turn, int index)
{
    switch (turn)
    {
    case 0:
        return index == 38;
    case 1:
        return index == 8;
    case 2:
        return index == 18;
    case 3:
        return index == 28;
    default:
        return false;
    }
}

bool isSafeCell(int index)
{
    for (int i = 0; i < sizeof(safe_cells) / sizeof(safe_cells[0]); i++)
    {
        if (safe_cells[i] == index)
            return true;
    }
    return false;
}

void moveOnFinal(Player players[MAX_PLAYERS][MAX_TOKENS], int turn, int choice)
{
    switch (turn)
    {
    case 0:
        players[turn][choice - 1].x += 1;
        break;
    case 2:
        players[turn][choice - 1].x -= 1;
        break;
    case 1:
        players[turn][choice - 1].y += 1;
        break;
    case 3:
        players[turn][choice - 1].y -= 1;
        break;
    default:
        break;
    }
}

struct ThreadData
{
    int player_id;
    char (*board)[SIZE];
    Player (*players)[MAX_PLAYERS][MAX_TOKENS];
    Cell (*cells)[PATH_CELLS];
};

void *playerThread(void *arg)
{
    ThreadData *data = (ThreadData *)arg;
    int player_id = data->player_id;
    char(*board)[SIZE] = data->board;
    Player(*players)[MAX_PLAYERS][MAX_TOKENS] = data->players;
    Cell(*cells)[PATH_CELLS] = data->cells;
    int result;

    unsigned int seed = chrono::system_clock::now().time_since_epoch().count() + player_id;
    srand(seed);

    while (!game_over)
    {
        sem_wait(&dice_semaphore);
        pthread_mutex_lock(&board_mutex);

        if (game_over)
        {
            pthread_mutex_unlock(&board_mutex);
            sem_post(&dice_semaphore);
            break;
        }

        displayCurrent(board, *players);
        cout << "It's time for player " << player_id + 1 << " to play." << endl;
        result = (rand() % MAX_DICE_COUNT) + 1;
        cout << "Dice roll result: " << result << endl;

        int choice;
        while (true)
        {
            cout << "Which piece would you like to move " << result << "? (1-" << num_tokens << "): ";
            cin >> choice;
            verifyInput();
            if (choice >= 1 && choice <= num_tokens)
                break;
            cout << "Invalid choice. Please select a piece between 1 and " << num_tokens << "." << endl;
        }

        if ((*players)[player_id][choice - 1].index == -1 && result == 6)
        {
            (*players)[player_id][choice - 1].index = getIndex(player_id);
            (*players)[player_id][choice - 1].x = (*cells)[getIndex(player_id)].x;
            (*players)[player_id][choice - 1].y = (*cells)[getIndex(player_id)].y;
        }
        else if ((*players)[player_id][choice - 1].index != -1)
        {
            int step = result;
            while (step > 0)
            {
                if (wayFinal(player_id, (*players)[player_id][choice - 1].index) && hit_rate[player_id] > 0)
                {
                    (*players)[player_id][choice - 1].index = 100;
                }
                if ((*players)[player_id][choice - 1].index < PATH_CELLS)
                {
                    (*players)[player_id][choice - 1].index = ((*players)[player_id][choice - 1].index + 1) % PATH_CELLS;
                    (*players)[player_id][choice - 1].x = (*cells)[(*players)[player_id][choice - 1].index].x;
                    (*players)[player_id][choice - 1].y = (*cells)[(*players)[player_id][choice - 1].index].y;
                }
                else
                {
                    (*players)[player_id][choice - 1].index = (*players)[player_id][choice - 1].index + 1;
                    moveOnFinal(*players, player_id, choice);
                    if ((*players)[player_id][choice - 1].x == 5 && (*players)[player_id][choice - 1].y == 5)
                    {
                        displayCurrent(board, *players);
                        finished_positions[player_id] = player_id + 1;
                        game_over = true;
                        break;
                    }
                }
                step--;
            }

            for (int i = 0; i < MAX_PLAYERS; i++)
            {
                if (i != player_id)
                {
                    for (int j = 0; j < 4; j++)
                    {
                        if ((*players)[i][j].x == (*players)[player_id][choice - 1].x && (*players)[i][j].y == (*players)[player_id][choice - 1].y && !isSafeCell((*players)[i][j].index))
                        {
                            (*players)[i][j].index = -1;
                            (*players)[i][j].x = houses[i][j].x;
                            (*players)[i][j].y = houses[i][j].y;
                            hit_rate[player_id]++;
                        }
                    }
                }
            }
        }

        consecutive_turns_no_six[player_id] = (result == 6) ? 0 : consecutive_turns_no_six[player_id] + 1;

        pthread_mutex_unlock(&board_mutex);
        sem_post(&dice_semaphore);
        sleep(1);
    }
    return NULL;
}

void *masterThread(void *arg)
{
    while (!game_over)
    {
        pthread_mutex_lock(&board_mutex);

        for (int i = 0; i < num_players; i++)
        {
            if (consecutive_turns_no_six[i] >= 20)
            {
                finished_positions[i] = -1;
                pthread_cancel(pthread_self());
                cout << "Player " << i + 1 << " has been kicked out of the game due to 20 consecutive turns without a six." << endl;
            }

            bool all_tokens_home = true;
            for (int j = 0; j < num_tokens; j++)
            {
                if (players[i][j].index != 100)
                {
                    all_tokens_home = false;
                    break;
                }
            }

            if (all_tokens_home)
            {
                finished_positions[i] = i + 1;
                game_over = true;
                break;
            }
        }

        pthread_mutex_unlock(&board_mutex);
        sleep(1);
    }

    return NULL;
}

void play(char board[SIZE][SIZE], int num_players)
{
    pthread_t threads[MAX_PLAYERS];
    pthread_t master_thread;
    int player_ids[MAX_PLAYERS];
    ThreadData thread_data[MAX_PLAYERS];

    sem_init(&dice_semaphore, 0, 1);
    pthread_mutex_init(&board_mutex, NULL);
    pthread_cond_init(&turn_cond, NULL);

    for (int i = 0; i < num_players; i++)
    {
        player_ids[i] = i;
        thread_data[i].player_id = player_ids[i];
        thread_data[i].board = board;
        thread_data[i].players = &players;
        thread_data[i].cells = &cells;
        pthread_create(&threads[i], NULL, playerThread, &thread_data[i]);
    }

    pthread_create(&master_thread, NULL, masterThread, NULL);

    while (!game_over)
    {
        sleep(1); // This ensures that the main thread can display updates periodically
    }

    for (int i = 0; i < num_players; i++)
    {
        pthread_join(threads[i], NULL);
    }

    pthread_join(master_thread, NULL);

    sem_destroy(&dice_semaphore);
    pthread_mutex_destroy(&board_mutex);
    pthread_cond_destroy(&turn_cond);

    // Display final results
    cout << "Game over! Final positions:" << endl;
    for (int i = 0; i < num_players; i++)
    {
        if (finished_positions[i] > 0)
        {
            cout << "Player " << i + 1 << " finished at position " << finished_positions[i] << "." << endl;
        }
        else
        {
            cout << "Player " << i + 1 << " did not finish." << endl;
        }
    }

    for (int i = 0; i < num_players; i++)
    {
        cout << "Player " << i + 1 << " hit rate: " << hit_rate[i] << endl;
    }
}

void menu(int &choice, int &players)
{
    titleDisplay();

    while (choice > 2 || choice < 1)
    {
        cout << endl
             << "1 - To Play" << endl;
        cout << "2 - To Quit" << endl
             << endl
             << ">";
        cin >> choice;
        verifyInput();
    }

    if (choice == 1)
    {
        while (players < 2 || players > 4)
        {
            cout << endl
                 << "Enter the number of players (2-4): " << endl
                 << endl
                 << ">";
            cin >> players;
            verifyInput();
        }

        while (num_tokens < 1 || num_tokens > 4)
        {
            cout << endl
                 << "Enter the number of tokens per player (1-4): " << endl
                 << endl
                 << ">";
            cin >> num_tokens;
            verifyInput();
        }
    }
}

int main()
{
    srand(static_cast<unsigned int>(std::time(nullptr)));

    initializeBoard(board);
    gameInitialization();

    while (true)
    {
        int choice = 0;
        int players = 0;
        menu(choice, players);

        if (choice == 2)
        {
            cout << endl
                 << "Stopping the game ..." << endl;
            return 0;
        }

        play(board, players);
    }

    return 0;
}
